"""Автосборщик Sonar в exe.

    python build.py            — полная сборка: зависимости → иконка → PyInstaller → deno → zip
    python build.py --no-install   не трогать pip (зависимости уже стоят)
    python build.py --no-zip       не упаковывать результат в zip
    python build.py --no-deno      не класть deno.exe рядом с программой
    python build.py --no-portable  данные в профиле Windows (%APPDATA%\\Sonar), а не рядом с программой

Результат: dist/Sonar/Sonar.exe (папка целиком — это программа) и dist/Sonar-ГГГГММДД.zip.
Сборка папкой, а не одним файлом: со встроенным браузером (вход в сервисы) один exe весит
сотни мегабайт и стартует по 10–20 секунд, папкой — запускается сразу.
"""
import argparse
import json
import datetime
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUILD, DIST = ROOT / "build", ROOT / "dist"
NAME = "Sonar"


def step(text: str) -> None:
    print(f"\n=== {text} ===", flush=True)


def fail(text: str) -> None:
    print(f"\nОШИБКА: {text}", flush=True)
    sys.exit(1)


def run(cmd: list[str]) -> None:
    print("> " + " ".join(cmd), flush=True)
    if subprocess.call(cmd, cwd=ROOT) != 0:
        fail("команда завершилась с ошибкой (подробности выше)")


def install() -> None:
    step("Зависимости")
    run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
    run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "pyinstaller>=6.0"])


def make_icon() -> Path:
    step("Иконка")
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    sys.path.insert(0, str(ROOT))
    from PyQt6.QtGui import QGuiApplication
    app = QGuiApplication.instance() or QGuiApplication([])  # noqa: F841 — нужен для рисования
    from sonar.ui.personalize import app_icon
    BUILD.mkdir(exist_ok=True)
    ico = BUILD / "sonar.ico"
    if not app_icon("standard", 256).toImage().save(str(ico)):
        png = BUILD / "sonar.png"   # без плагина ICO — PyInstaller сам сконвертирует PNG (нужен Pillow)
        app_icon("standard", 256).toImage().save(str(png))
        ico = png
    print(f"иконка: {ico}")
    return ico


SHARED = "shared_navidrome.json"


def prepare_shared() -> Path | None:
    """Общий Navidrome: shared_navidrome.json в корне проекта → в сборку, с токеном вместо пароля."""
    src = ROOT / SHARED
    if not src.exists():
        return None
    step("Общий сервер Navidrome")
    sys.path.insert(0, str(ROOT))
    from sonar.shared_server import to_token
    data = to_token(json.loads(src.read_text("utf-8")))
    if not (data.get("url") and data.get("user") and data.get("token")):
        fail(f"в {src.name} нужны url, user и password")
    out = ROOT / "sonar" / "assets" / SHARED
    out.write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")
    print(f"сервер {data['url']}, пользователь {data['user']} — подключится у всех сам")
    return out


def pyinstaller(icon: Path) -> Path:
    step("PyInstaller")
    sep = os.pathsep
    args = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--windowed", "--onedir",
            "--name", NAME, "--icon", str(icon),
            "--distpath", str(DIST), "--workpath", str(BUILD / "pyinstaller"), "--specpath", str(BUILD),
            "--add-data", f"{ROOT / 'sonar' / 'assets'}{sep}sonar/assets",   # аватарки, иконки сервисов
            "--collect-submodules", "sonar",
            "--collect-data", "ytmusicapi",       # языковые файлы для разбора ответов YouTube Music
            "--collect-submodules", "yandex_music"]
    try:
        import yt_dlp_ejs  # noqa: F401 — JS-скрипты yt-dlp для YouTube
        args += ["--collect-all", "yt_dlp_ejs"]
    except ImportError:
        print("предупреждение: yt-dlp-ejs не установлен — YouTube в exe может не работать")
    args.append(str(ROOT / "main.py"))
    started = time.monotonic()
    run(args)
    folder = DIST / NAME
    exe = folder / (f"{NAME}.exe" if os.name == "nt" else NAME)
    if not exe.exists():
        fail(f"PyInstaller не создал {exe}")
    print(f"готово за {time.monotonic() - started:.0f} с: {exe}")
    return folder


def add_deno(folder: Path) -> None:
    step("Deno (нужен yt-dlp для YouTube)")
    exe = "deno.exe" if os.name == "nt" else "deno"
    found = shutil.which("deno") or next((str(p) for p in (Path.home() / ".deno" / "bin" / exe,) if p.exists()), None)
    if not found:
        print("Deno не найден: YouTube Music и подбор треков для Spotify/Deezer на ПК без Deno работать не будут.\n"
              "Установите (winget install DenoLand.Deno) и пересоберите — он положится рядом с Sonar.exe.")
        return
    shutil.copy2(found, folder / exe)
    print(f"скопирован {found} → {folder / exe}")


PORTABLE_NOTE = """Этот файл включает портативный режим Sonar.

Пока он лежит рядом с Sonar.exe, все данные — настройки, подключённые сервисы, профиль, лайки,
плейлисты, история, журнал и скачанные треки — хранятся в папке data рядом с программой.
Папку Sonar можно переносить куда угодно (другой диск, флешка, другой ПК): данные едут вместе с ней.
Если папки data нет, Sonar создаст новую, как при первом запуске.

Удалите этот файл, чтобы хранить данные в профиле Windows (%APPDATA%\\Sonar).
"""


def make_portable(folder: Path) -> None:
    step("Портативный режим")
    (folder / "portable.txt").write_text(PORTABLE_NOTE, "utf-8")
    stale = folder / "data"   # данные с машины сборщика в архив не попадают
    if stale.exists():
        shutil.rmtree(stale)
    print("данные будут храниться в папке data рядом с Sonar.exe")


def make_zip(folder: Path) -> Path:
    step("Архив")
    base = DIST / f"{NAME}-{datetime.date.today():%Y%m%d}"
    archive = Path(shutil.make_archive(str(base), "zip", root_dir=DIST, base_dir=folder.name))
    print(f"{archive} ({archive.stat().st_size / 1048576:.0f} МБ)")
    return archive


def main() -> None:
    parser = argparse.ArgumentParser(description="Сборка Sonar в exe")
    parser.add_argument("--no-install", action="store_true", help="не устанавливать зависимости")
    parser.add_argument("--no-zip", action="store_true", help="не упаковывать в zip")
    parser.add_argument("--no-deno", action="store_true", help="не класть deno рядом с программой")
    parser.add_argument("--no-portable", action="store_true", help="данные в профиле Windows, а не рядом")
    opts = parser.parse_args()
    if sys.version_info < (3, 10):
        fail("нужен Python 3.10 или новее")
    if os.name != "nt":
        print("Внимание: сборка не на Windows — получится программа для этой системы, а не .exe.")
    print(f"Python {platform.python_version()} ({sys.executable})")
    if not opts.no_install:
        install()
    icon = make_icon()
    shared = prepare_shared()
    try:
        folder = pyinstaller(icon)
    finally:
        if shared is not None:
            shared.unlink(missing_ok=True)   # токен — только внутри сборки, не в исходниках
    if not opts.no_deno:
        add_deno(folder)
    if not opts.no_portable:
        make_portable(folder)
    archive = None if opts.no_zip else make_zip(folder)
    step("Готово")
    print(f"Программа: {folder}  (запуск — {NAME}.exe; переносите папку целиком)")
    if not opts.no_portable:
        print("Портативная: данные в папке data рядом с exe, папку можно класть куда угодно.")
    if archive:
        print(f"Архив для переноса: {archive}")


if __name__ == "__main__":
    main()
